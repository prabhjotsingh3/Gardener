#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <FS.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include <Time.h>
#include <TimeLib.h>
#include <EEPROM.h>
#include <TimeAlarms.h>

/* Currently Supported features :-
 * -> Automatic Watering of plants (once in a day).
 * -> Control to turn on pump for 10 seconds from web page.
 * -> Water Tank levels are indicated on Web page as well as Circuit board.
 * -> Rightmost Green LED indicates the pump status.
 * -> There is no onboard RTC. Time is synced via NTP.
 */
/* Missing :-
 * -> Pump Control via switch.
 * -> Pump Status isn't shown anywhere.
 */

/* Web Request Handler 
 * TODO -> Common Handler for all static web pages
 * (i.e., the one read from file system).
*/
extern void handleRoot(void);
extern void handleNotFound(void);
extern void handleCssRequest(void);
extern void handleLowImgRequest(void);
extern void handleMedImgRequest(void);
extern void handleHighImgRequest(void);
extern void handleWaterNowRequest(void);
extern void handleUpdateTimeRequest(void);
time_t getNtpTime(void);
/*
 * D5 (GPIO 14) -> Water Tank Empty Interrupt
 * D6 (GPIO 12) -> Water Tank Full Interrupt
 * D7 (GPIO 13) -> Water Pump On/Off Switch
 * D8 (GPIO 15) -> Water Pump Control Output
 * D1 (GPIO 5) -> Water Tank Empty Indicator
 * D2 (GPIO 4) -> Water Tank Full Indicator
*/
#define PUMP_ON_INDICATOR       16
#define TANK_EMPTY_INTR_PIN     14
#define TANK_FULL_INTR_PIN      12
#define PUMP_CTRL_SWITCH        13
#define PUMP_CTRL_PIN           15
#define TANK_EMPTY_LED_PIN      5
#define TANK_FULL_LED_PIN       4

/* We can save a list of supported SSIDs and Passwords in a file. */
#define LOCAL_NETWORK_SSID    "Shinchan"
#define LOCAL_NETWORK_PASS    "freehailelo"

#define GARDENER_AP_NAME        "Gardener"
#define GARDENER_AP_PASS        "Gardener@3"

/* Server Object */
ESP8266WebServer Gardener(80);

/* Tank Level Variables */
bool tankEmpty = false;
bool tankFull = false;

/* Pump Control Variables */
bool waterNow = false;
int pumpOnCounter = 0;

/* NTP related stuff*/
const long utcOffsetInSeconds = 19800; /* UTC + 5:30*/ 
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", utcOffsetInSeconds);

/* Watering time EEPROM address */
#define WATERING_HOUR_EEPROM_ADDR       0x00
#define WATERING_MIN_EEPROM_ADDR        0x01
/* Alarm ID for Daily Watering Feature */
AlarmID_t waterPumpAlarmId;

/* Reads Watering Time(Hour) from EEPROM */
unsigned char getWateringTimeHour(void) {
  return EEPROM.read(WATERING_HOUR_EEPROM_ADDR);
}

/* Reads Watering Time(Minutes) from EEPROM */
unsigned char getWateringTimeMinute(void) {
  return EEPROM.read(WATERING_MIN_EEPROM_ADDR);
}

/* Writes Watering Time(Hour) from EEPROM */
void updateWateringTimeHour(unsigned char val) {
  EEPROM.write(WATERING_HOUR_EEPROM_ADDR, val);
  EEPROM.commit();
}

/* Writes Watering Time(Minutes) from EEPROM */
void updateWateringTimeMinute(unsigned char val) {
  EEPROM.write(WATERING_MIN_EEPROM_ADDR, val);
  EEPROM.commit();
}

/* Tank Empty Interrupt handler */
/* TODO : Should we take care of babbling as well? */
ICACHE_RAM_ATTR void waterTankEmptyISR(void) {
  unsigned char data;
  data = digitalRead(TANK_EMPTY_INTR_PIN);
  if(data ==  true) {
    Serial.println("Water Tank Empty");
    /* Turn on Tank Empty LED  */
    digitalWrite(TANK_EMPTY_LED_PIN, true);
    tankEmpty = true;
  }
  else {
    Serial.println("Water Tank Not Empty");
    digitalWrite(TANK_EMPTY_LED_PIN, false);
    tankEmpty = false;
  }
}

/* Tank Full Interrupt handler */
ICACHE_RAM_ATTR void waterTankFullISR(void) {
  unsigned char data;;
  data = digitalRead(TANK_FULL_INTR_PIN);
  if(data == false) {
    Serial.println("Water Tank Full");
    /* Turn on Tank Full LED */
    digitalWrite(TANK_FULL_LED_PIN, false);
    tankFull = true;
  }
  else {
    Serial.println("Water Tank Not Full");
    digitalWrite(TANK_FULL_LED_PIN, true);
    tankFull = false;
  }
}

/* Pump Control Switch Interrupt Handler -> Not being used currently */
ICACHE_RAM_ATTR void waterPumpSwitchISR(void) {
  Serial.println("Toggle Water Pump Status");
}

/* Turns on Water Pump */
void turnOnPump(void) {
  Serial.println("Pump on");
  digitalWrite(PUMP_CTRL_PIN, true);
  digitalWrite(PUMP_ON_INDICATOR, false);
}

/* Turns off Water Pump */
void turnOffPump(void) {
  Serial.println("Pump off");
  digitalWrite(PUMP_CTRL_PIN, false);
  digitalWrite(PUMP_ON_INDICATOR, true);
}

/* Sets flag to turn on water pump */
void waterPlants(void) {
  Serial.println("Alarm activated");
  if(tankEmpty != true) {
    waterNow = true;
    pumpOnCounter = 0;
  }
  else {
    Serial.println("Tank Empty. Pump will not be turned on.");
  }
}

/* Inits daily alarm for watering plants */
AlarmID_t waterPumpAlarmSetup(unsigned char h, unsigned char m) {
  Serial.print("Alarm setup at : ");
  Serial.print(h);
  Serial.print(":");;
  Serial.println(m);
  return(Alarm.alarmRepeat(h, m, 0, waterPlants));
}

/* Updates time of daily watering time */
void waterPumpAlarmUpdate(void) {
  Alarm.free(waterPumpAlarmId);
  waterPumpAlarmId = waterPumpAlarmSetup(getWateringTimeHour(), getWateringTimeMinute());
}

void setup() {
  wl_status_t wl_status = WL_CONNECTED;

  // put your setup code here, to run once:
  Serial.begin(115200);

  Serial.println("\n\n\n********* Automatic Plant Watering System *********");

  Serial.println("Initializing I/O pins");
  
  pinMode(TANK_EMPTY_INTR_PIN, INPUT_PULLUP);
  pinMode(TANK_FULL_INTR_PIN, INPUT_PULLUP);

  /*TODO : Enable remaining pins as well */
  pinMode(TANK_EMPTY_LED_PIN, OUTPUT);
  pinMode(TANK_FULL_LED_PIN, OUTPUT);
  pinMode(PUMP_CTRL_PIN, OUTPUT);
  pinMode(PUMP_ON_INDICATOR, OUTPUT);
  digitalWrite(PUMP_CTRL_PIN, false);
  digitalWrite(PUMP_ON_INDICATOR, true);

  /* Initialize tank level variables and LEDs */
  tankEmpty = digitalRead(TANK_EMPTY_INTR_PIN);
  tankFull = !(digitalRead(TANK_FULL_INTR_PIN));
  digitalWrite(TANK_EMPTY_LED_PIN, tankEmpty);
  digitalWrite(TANK_FULL_LED_PIN, !tankFull);

  Serial.println("I/O Pins Init Done");

  Serial.println("Enabling Interrupts");
  attachInterrupt(digitalPinToInterrupt(TANK_EMPTY_INTR_PIN), waterTankEmptyISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(TANK_FULL_INTR_PIN), waterTankFullISR, CHANGE);
  Serial.println("Interrupts Enabled");

  Serial.println("Initializing file system");
  if(!SPIFFS.begin()){
    Serial.println("An Error has occurred while mounting SPIFFS");
    return;
  }
  Serial.println("File System Init done");

  Serial.println("Setting up Wifi (STA + AP Mode)");

  /* TODO : Check return code for below WIFI calls */

  /* Set AP + STA mode */
  WiFi.mode(WIFI_AP_STA);

  /* Setup AP */
  WiFi.softAP(GARDENER_AP_NAME, GARDENER_AP_PASS);

  /* Connect to local network */
  Serial.print("Connecting to network ");
  Serial.println(LOCAL_NETWORK_SSID);
  WiFi.begin(LOCAL_NETWORK_SSID, LOCAL_NETWORK_PASS);
  do {
    wl_status = WiFi.status();
    if(wl_status == WL_CONNECT_FAILED) {
      break;
    }
    Serial.print(".");
    delay(1000);
  }while(wl_status != WL_CONNECTED);

  if(wl_status == WL_CONNECTED) {
    Serial.println("\r\nSuccess");
    Serial.print("IP Address : ");
    Serial.println(WiFi.localIP());
  }
  else { /* TODO : Add Error handling here */
    Serial.println("Failed");
  }

  /* Print SoftAP and STA details */
  
  /* Web Server setup */
  Gardener.on("/", handleRoot);
  Gardener.on("/index.html", handleRoot);
  Gardener.on("/style.css", handleCssRequest);
  Gardener.on("/images/low.jpg", handleLowImgRequest);
  Gardener.on("/images/med.jpg", handleMedImgRequest);
  Gardener.on("/images/high.jpg", handleHighImgRequest);
  Gardener.on("/waterNow.html", handleWaterNowRequest);
  Gardener.on("/updateTime.html", handleUpdateTimeRequest);
  
  Gardener.onNotFound(handleNotFound);

  Gardener.begin();
  Serial.println("Web Server setup done");

  Serial.println("Setting up NTP Client");
  timeClient.begin();
  setSyncProvider(getNtpTime); /* Default sync time ->  5 minutes */
  Serial.println("NTP Client setup done");

  Serial.println("Setting up EEPROM");
  EEPROM.begin(512);
  Serial.print("Watering Time is set at : ");
  Serial.print(getWateringTimeHour());
  Serial.print(":");
  Serial.print(getWateringTimeMinute());
  Serial.println("\nEEPROM Setup Done");
  
  Serial.println("Setting up Alarms");
  waterPumpAlarmId = waterPumpAlarmSetup(getWateringTimeHour(), getWateringTimeMinute());
  Serial.println(waterPumpAlarmId);
  Serial.println("Alarm Setup Done");
}
/* NOTE - In order to use Alarm, we must call Alarm.delay() from main loop */
void loop() {
  // put your main code here, to run repeatedly:
  //Serial.println("Going to sleep");
  Gardener.handleClient();
  if(waterNow) {
    if((pumpOnCounter) < 1000) {
      if(pumpOnCounter == 0) {
        turnOnPump();
      }
      Alarm.delay(10);
      pumpOnCounter++;
    }
    else {
      waterNow = false;
      pumpOnCounter = 0;
      turnOffPump();
    }
  } else {
    Alarm.delay(1);
  }
}

/* Returns current timestamp 
 * Synced via NTP.
 */
time_t getNtpTime(){
  timeClient.update();
  Serial.println("Time updated");
  return timeClient.getEpochTime();
}