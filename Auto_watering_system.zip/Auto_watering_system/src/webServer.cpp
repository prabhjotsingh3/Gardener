#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <FS.h>
#include <Time.h>
#include<TimeLib.h>

extern char index_str[];
extern char waterNowStr[];
extern char waterNowErrStr[];
extern char updateTimeStr[];
extern ESP8266WebServer Gardener;
extern bool tankEmpty;
extern bool tankFull;

extern void waterPlants(void);
extern char watering_hour, watering_minute;
extern unsigned char getWateringTimeHour(void);
extern unsigned char getWateringTimeMinute(void);
extern  void updateWateringTimeHour(unsigned char);
extern void updateWateringTimeMinute(unsigned char);

void handleRoot(void) {
    char img_name[5];
    char banner_str[60];
    char final_index_str[2000];

    if(tankEmpty == true) {
        strcpy(img_name, "low");
        strcpy(banner_str, "<h3 class=\"warningBanner\">please fill water in tank!!!</h3>");
    }
    else if(tankFull  ==true) {
        strcpy(img_name, "high");
        strcpy(banner_str, "<h3 >Tank Full</h3>");
    }
    else {
        strcpy(img_name, "med");
        strcpy(banner_str, "<h3 >Tank Level OK</h3>");
    }

    sprintf(final_index_str,index_str,img_name,banner_str, getWateringTimeHour(), getWateringTimeMinute(), hour(), minute(), second());
    Gardener.send(200, "text/html", final_index_str);
}

void handleCssRequest(void) {
    Serial.println("CSS Request received");
    Serial.println(Gardener.uri());
    File file = SPIFFS.open("/style.css", "r");
    Gardener.streamFile(file, "text/css");
    file.close(); 
}

void handleLowImgRequest(void)  {
    Serial.println("Low Img Request received");
    Serial.println(Gardener.uri());
    File file = SPIFFS.open("/images/low.jpg", "r");
    Gardener.streamFile(file, "text/jpeg");
    file.close(); 
}

void handleMedImgRequest(void) {
    Serial.println("Med Img Request received");
    Serial.println(Gardener.uri());
    File file = SPIFFS.open("/images/med.jpg", "r");
    Gardener.streamFile(file, "text/jpeg");
    file.close(); 
}

void handleHighImgRequest(void) {
    Serial.println("High Img Request received");
    Serial.println(Gardener.uri());
    File file = SPIFFS.open("/images/high.jpg", "r");
    Gardener.streamFile(file, "text/jpeg");
    file.close();
}

void handleWaterNowRequest(void) {
    Serial.println("Water Now Button pressed");
    if(tankEmpty == true) {
        Gardener.send(200, "text/html",waterNowErrStr);
    }
    else {
        Gardener.send(200, "text/html",waterNowStr);
        /* Set variable to enable pump */
        waterPlants();
    }
}
void waterPumpAlarmUpdate(void);
void handleUpdateTimeRequest(void) {
    String new_hour, new_minute;
    String new_time;
    Serial.println("Update time request received");
    new_time = Gardener.arg("newTime");
    new_hour = new_time.substring(0, 2);
    new_minute = new_time.substring(3,5);
    updateWateringTimeHour(new_hour.toInt());
    updateWateringTimeMinute(new_minute.toInt());
    waterPumpAlarmUpdate();
    Gardener.send(200, "text/html",updateTimeStr);
}

void handleNotFound(void) {
    Gardener.send(404, "text/plain", "404: Not found");
}